#!/usr/bin/env python3

import psycopg2


def main():
    # Connect to an existing database
    conn = psycopg2.connect("dbname=news")

    # Open a cursor to perform database operations
    cur = conn.cursor()

    # Question 1
    well_popular_articles = """
      SELECT aut__art_path_count_view.title, aut__art_path_count_view.view
      FROM aut__art_path_count_view
      ORDER BY aut__art_path_count_view.view DESC
      LIMIT 3;
    """
    cur.execute(well_popular_articles)
    print("three Most popular articles:")
    for (title, view) in cur.fetchall():
        print("    {} - {} views".format(title, view))
    print("-" * 70)

    # Question 2
    the_most_popular_authors = """
    SELECT aut__art_path_count_view.name, SUM(aut__art_path_count_view.view) AS total_author_view
    FROM aut__art_path_count_view
    GROUP BY aut__art_path_count_view.name
    ORDER BY total_author_view DESC;
    """
    cur.execute(the_most_popular_authors)
    print("Most popular authors:")
    for (name, view) in cur.fetchall():
        print("    {} - {} views".format(name, view))
    print("-" * 70)

    # Question 3
    more_than_one_percent_conection_and_other_error = """
    SELECT *
    FROM error_rate_percent
    WHERE error_rate_percent.percentage > 1
    ORDER BY error_rate_percent.percentage DESC;
    """
    cur.execute(more_than_one_percent_conection_and_other_error)
    print("Days with more than 1% errors:")
    for (date, percentage) in cur.fetchall():
        print("    {} - {}% errors".format(date, percentage))
    print("-" * 70)

    # Close communication with the database
    cur.close()
    conn.close()

if __name__ == "__main__":
    main()
