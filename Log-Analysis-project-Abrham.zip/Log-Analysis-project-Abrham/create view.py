CREATE VIEW aut__art_view AS
SELECT authors.name, articles.title, articles.slug
FROM articles, authors
WHERE articles.author = authors.id
ORDER BY authors.name;

CREATE VIEW path_count_view AS
SELECT path, COUNT(*) AS path_view
FROM log
GROUP BY path
ORDER BY path;

CREATE VIEW aut__art_path_count_view AS
SELECT author_info.name, author_info.title, path_view.view
FROM author_info, path_view
WHERE path_view.path = CONCAT('/article/', author_info.slug)
ORDER BY author_info.name;

CREATE VIEW total_time_view AS
SELECT date(time), COUNT(*) AS t_time_views
FROM log 
GROUP BY date(time)
ORDER BY date(time);

CREATE VIEW total_error_view AS
SELECT date(time), COUNT(*) AS total_errors
FROM log WHERE status = '404 NOT FOUND' 
GROUP BY date(time) 
ORDER BY date(time);


CREATE VIEW error_rate_percent AS
SELECT total_view.date, (100.0*error_view.errors/total_view.views) AS percentage
FROM total_view, error_view
WHERE total_view.date = error_view.date
ORDER BY total_view.date;
